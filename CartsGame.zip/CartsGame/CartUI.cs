﻿using UnityEngine;
using UnityEngine.EventSystems;

public class CartUI : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Cart UI;
    private Animator anim;

    private void Start()
    {
        anim = GetComponent<Animator>();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        anim.SetBool("Up",true);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        anim.SetBool("Up", false);
    }
}
