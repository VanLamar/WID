﻿using UnityEngine;

[CreateAssetMenu(menuName ="Create/Cart")]
public class Cart : ScriptableObject
{
    public string Name;
    [TextArea(3,10)]
    public string Description;
    public Sprite Icon;
    public int Damage;
}
