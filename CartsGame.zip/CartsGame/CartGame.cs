﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CartGame : MonoBehaviour
{
    [SerializeField] private GameObject panel;
    [SerializeField] private GameObject prefabCart;
    [SerializeField] private List<Cart> playersCarts = new List<Cart>();

    private void Start()
    {
        foreach (var playerCart in playersCarts)
        {
            var cart = Instantiate(prefabCart, panel.transform);
            cart.GetComponent<Image>().sprite = playerCart.Icon;
            print(playerCart.Name);
        }
    }
}
