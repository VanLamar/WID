﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

public class AchievementManager : MonoBehaviour
{
    public static AchievementManager Instance;
    public List<Achievement> achievements = new List<Achievement>();

    [SerializeField] private GameObject UI;
    private int timer;
    private bool isCanBeShowen = false;

    private void Start()
    {
        Instance = this;
        timer = 0;
    }

    private void Update()
    {
        if (isCanBeShowen)
            timer++;

        if (timer >= 300)
        {
            UI.SetActive(false);
            timer = 0;
            isCanBeShowen = false;
        }
    }

    public void CheckAchievement(string achievementName, int currentPoints)
    {
        foreach (Achievement achievement in achievements)
        {
            if (achievement.Id == achievementName && !achievement.IsUnlocked && currentPoints >= achievement.PointsRequired)
            {
                UnlockAchievement(achievement);
            }
        }
    }

    private void UnlockAchievement(Achievement achievement)
    {
        UI.SetActive(true);
        achievement.IsUnlocked = true;

        UI.transform.GetChild(0).GetComponent<Image>().sprite = achievement.Icon;
        UI.transform.GetChild(1).GetComponent<Text>().text = achievement.Name[SetUpWorld.Instance.LoadIndexDialogueLang()];
        UI.transform.GetChild(2).GetComponent<Text>().text = achievement.Description[SetUpWorld.Instance.LoadIndexDialogueLang()];

        Debug.Log($"Achievement Unlock: {achievement.name}");
        isCanBeShowen = true;
    }
}
