﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public Item CurretItem;
    public Item item1;
    public Item item2;
    public Item item3;
    [SerializeField] private GameObject InventoryPanel;
    [SerializeField] private Transform ControlInventory;
    [SerializeField] private GameObject ItemPrefab;
    [SerializeField] private int maxSlots = 32;
    [SerializeField] private int maxSlotsControll = 4;
    [HideInInspector]public List<InventorySlot> MainSlots => slots;
    [HideInInspector]public List<InventorySlot> ControlSlots => slotsControll;

    private bool isOpen = false;
    private int uniqueIDCounter = 0; 
    private List<InventorySlot> slots = new List<InventorySlot>();
    private List<InventorySlot> slotsControll = new List<InventorySlot>();

    private void Start()
    {
        AddItem(item1);
        AddItem(item2);
        AddItem(item3);
    }

    public void AddItem(Item item, int idInv = 0)
    {
        GameObject newIt = null;
        InventorySlot newSlot = null;
        switch (idInv)
        {
            case 0:
                if (slots.Count >= maxSlots)
                    return;

                newIt = Instantiate(ItemPrefab, InventoryPanel.transform);
                newSlot = new InventorySlot(newIt, uniqueIDCounter++);
                slots.Add(newSlot);
                break;
            case 1:
                if (slotsControll.Count >= maxSlotsControll)
                    return;

                newIt = Instantiate(ItemPrefab, ControlInventory);
                newSlot = new InventorySlot(newIt, uniqueIDCounter++);
                slotsControll.Add(newSlot);
                break;
        }

        newSlot.SetItem(item);
        newIt.name = $"Item{item.ID}";
    }

    public List<Item> CurrentItems()
    {
        return slots.Select(slot => slot.ContainedItem).ToList();
    }


    public void RemoveItem(int uniqueID)
    {
        InventorySlot slotToRemove = slots.Find(slot => slot.UniqueID == uniqueID);
        if (slotToRemove == null)
            slotToRemove = slotsControll.Find(slot => slot.UniqueID == uniqueID);

        if (slotToRemove != null)
        {
            Destroy(slotToRemove.SlotObject);
            slots.Remove(slotToRemove);
            slotsControll.Remove(slotToRemove);
        }
    }

    public void RemoveItemFromMain(Item item)
    {
        InventorySlot slotToRemove = slots.Find(slot => slot.ContainedItem == item);
        Destroy(slotToRemove.SlotObject);
        slots.Remove(slotToRemove);
    }


    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q))
            SwitchPanel();

        if (Input.GetKeyDown(KeyCode.U))
            SaveInventory();

        //if (Input.GetKeyDown(KeyCode.LeftShift))
        //    AddItem(CurretItem);

        //if (Input.GetKeyDown(KeyCode.RightShift))
        //{
        //    InventorySlot slotToRemove = slots.Find(slot => slot.ContainedItem == CurretItem);
        //    if (slotToRemove != null)
        //        RemoveItem(slotToRemove.UniqueID);
        //}
    }


    public bool IsInMainInventory(int uniqueID)
    {
        return slots.Exists(slot => slot.UniqueID == uniqueID);
    }

    public bool IsInControlInventory(int uniqueID)
    {
        return slotsControll.Exists(slot => slot.UniqueID == uniqueID);
    }

    private Item GetItemByUniqueID(int uniqueID)
    {
        InventorySlot foundSlot = slots.Find(slot => slot.UniqueID == uniqueID);
        if (foundSlot != null)
            return foundSlot.ContainedItem;
        return null;
    }


    public void MoveToControl(int uniqueID)
    {
        if (slotsControll.Count >= maxSlotsControll)
            return;

        Item item = GetItemByUniqueID(uniqueID);
        if (item == null)
            return;

        RemoveItem(uniqueID); 
        GameObject newIt = Instantiate(ItemPrefab, ControlInventory);
        InventorySlot newSlot = new InventorySlot(newIt, uniqueIDCounter++);
        newSlot.SetItem(item);
        newIt.name = $"Item{item.ID}";
        slotsControll.Add(newSlot);
    }

    public void SaveInventory()
    {
        List<ItemData> itemsData = new List<ItemData>();
        foreach (var slot in slots)
        {
            Item item = slot.ContainedItem;
            itemsData.Add(new ItemData { ID = item.ID, Quantity = item.Quantity });
        }

        string json = JsonUtility.ToJson(new InventoryData { Items = itemsData.ToArray() });
        File.WriteAllText(Application.persistentDataPath + "/Inventory.wfs", json);
    }

    public void LoadInventory()
    {
        string filePath = Application.persistentDataPath + "/Inventory.wfs";

        if (!File.Exists(filePath))
        {
            //Debug.LogError("Inventory file does not exist!");
            return;
        }

        string json = File.ReadAllText(filePath);
        InventoryData inventoryData = JsonUtility.FromJson<InventoryData>(json);

        slots.Clear();

        foreach (var itemData in inventoryData.Items)
        {
            Item item = WorldParameters.Instance.ItemsData[itemData.ID];
            item.Quantity = itemData.Quantity;
            AddItem(item);
        }
    }

    public void HideInventory()
    {
        isOpen = false;
        InventoryPanel.SetActive(isOpen);
    }

    public void SwitchPanel() 
    {
       isOpen = !isOpen;
       InventoryPanel.SetActive(isOpen);
    }
}

[System.Serializable]
public class InventoryData
{
    public ItemData[] Items;
}

[System.Serializable]
public class ItemData
{
    public int ID;
    public int Quantity;
}
