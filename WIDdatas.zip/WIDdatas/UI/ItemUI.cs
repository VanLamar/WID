﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class ItemUI : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Item item;
    public int id;

    private Tooltip tooltip;
    private Inventory inventory; 
    private float hoverTime = 0f;
    private bool isHovering = false;
    private int langIndex;

    private void Start()
    {
        langIndex = SetUpWorld.Instance.LoadIndexDialogueLang();
        tooltip = FindObjectOfType<Tooltip>();
        inventory = FindObjectOfType<Inventory>(); 
    }

    private void Update()
    {
        HandleTooltipDisplay();
    }

    private void HandleTooltipDisplay()
    {
        if (isHovering)
        {
            hoverTime += Time.deltaTime;
            if (hoverTime >= 1f && !inventory.IsInControlInventory(item.ID))
            {
                DisplayTooltip();
            }
        }
    }

    private void DisplayTooltip()
    {
        string content = GetItemContent();
        tooltip.ShowTooltip(content);
    }

    private string GetItemContent()
    {
        string itemName = item.Name.Length > 1 ? item.Name[langIndex] ?? item.Name[0] : Localization.GetLocalizedString("ErrorNameItem");
        string itemDescription = item.Description.Length > 1 ? item.Description[langIndex] ?? item.Description[0] : Localization.GetLocalizedString("ErrorDescItem");
        return $"<color=red>{itemName}</color>\n{itemDescription}";
    }



    public void OnPointerEnter(PointerEventData eventData)
    {
        isHovering = true;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        isHovering = false;
        hoverTime = 0f;
        tooltip.HideTooltip();
    }

    private void Use() => item.UseItem(id);

    public void SetUp()
    {
        GetComponent<Image>().sprite = item.Icon;
        GetComponent<Button>().onClick.RemoveAllListeners();
        GetComponent<Button>().onClick.AddListener(Use);
    }
}
