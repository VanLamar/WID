﻿using UnityEngine;
using UnityEngine.UI;

public class Tooltip : MonoBehaviour
{
    [SerializeField] private Text tooltipText;
    [SerializeField] private RectTransform tooltipPanelRectTransform;
    [SerializeField] private float offsetX = 5f;

    private void Start()
    {
        HideTooltip();
    }

    public void ShowTooltip(string content)
    {
        tooltipText.text = content;
        tooltipPanelRectTransform.gameObject.SetActive(true);

        Vector2 mousePosition = Input.mousePosition;
        tooltipPanelRectTransform.position = new Vector3(mousePosition.x + offsetX, mousePosition.y, 0);
    }

    public void HideTooltip()
    {
        tooltipPanelRectTransform.gameObject.SetActive(false);
    }
}
