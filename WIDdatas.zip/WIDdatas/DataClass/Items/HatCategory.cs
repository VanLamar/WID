﻿using UnityEngine;

[CreateAssetMenu(fileName = "Hat", menuName = "Custom/Items/HatCategory")]
public class HatCategory : Item
{
    public OutfitType outfitType = OutfitType.Hat;
    public enum OutfitType { Hat, Accessory }
    public Vector3 newPoss;
    public Vector3 newScale = new Vector3(0.6288531f, 0.5984483f, 2.232429f);

    private GameObject outfit;
    private Transform playerTransform;

    public override void UseItemControl(int uniqueID)
    {
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;

        switch (outfitType)
        {
            case OutfitType.Hat:
                outfit = playerTransform.Find("Hat")?.gameObject;
                WorldParameters.Instance.DataPlayer.Hat = this;
                break;
            case OutfitType.Accessory:
                outfit = playerTransform.Find("Accessory")?.gameObject;
                WorldParameters.Instance.DataPlayer.Accessory = this;
                break;
        }
        if (outfit.GetComponent<Outfit>().hat != null)
            inventory.AddItem(outfit.GetComponent<Outfit>().hat, 1);

        outfit.GetComponent<SpriteRenderer>().sprite = Icon;
        outfit.transform.localPosition = newPoss;
        outfit.transform.localScale = newScale;
        outfit.GetComponent<Outfit>().hat = this;
        base.UseItemControl(uniqueID);
    }
}
