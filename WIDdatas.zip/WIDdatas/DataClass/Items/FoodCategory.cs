﻿using UnityEngine;

[CreateAssetMenu(fileName = "Food", menuName = "Custom/Items/FoodCategory")]
public class FoodCategory : Item
{
    public int Nasality;
    private WorldParameters parameters => WorldParameters.Instance;
    public override void UseItemControl(int uniqueID)
    {
        if (parameters.DataPlayer.MentalHealth >= 100)
            return;

        parameters.DataPlayer.MentalHealth += Nasality;
        base.UseItemControl(uniqueID);
    }
}
