﻿using UnityEngine;

public class Outfit : MonoBehaviour
{
    public HatCategory hat;
}
