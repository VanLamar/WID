﻿using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "Message", menuName = "Custom/Action/Message")]
public class Message : ActionP
{
    public string NameUI;
    public TypeMessage typeMessage = TypeMessage.Dialogue;
    public enum TypeMessage { Dialogue, Letter }
    public TextAsset[] monologues;
    public Font[] fonts;

    GameObject letter;


    public override void LoadResurces()
    {
        letter = SetUpWorld.Instance.ImportantObjects[1];
    }

    public override void Interaction(GameObject ActionObect)
    {
        switch (typeMessage)
        {
            case TypeMessage.Dialogue:
                StartMessage();
                break;
            case TypeMessage.Letter:
                StartLetter();
                break;
        }
    }


    public void StartMessage()
    {
        if (!dialogueManager.isTalking)
            dialogueManager.StartMonologue(JsonUtility.FromJson<Dialogue>(monologues[LoadIndexDialogueLang()].text));
    }

    public void StartLetter()
    {
        letter.SetActive(true);
        letter.transform.GetChild(0).GetComponent<Text>().text = SetMessange();
        letter.transform.GetChild(0).GetComponent<Text>().font = fonts[LoadIndexDialogueLang()];
    }

    public override void EndInteraction()
    {
        if (letter != null)
         letter.SetActive(false);
    }

    private string SetMessange()
    {
        string message = Localization.GetLocalizedString(parameters.CatName + "_cat");

        if (message == "Localization_error01" && parameters.CatName.Length != 0)
            return Localization.GetLocalizedString("NoneNameCat") + parameters.CatName;


        if (message == "Localization_error01")
        {
            message = Localization.GetLocalizedString("default_cat");
            parameters.CatName = Localization.GetLocalizedString("default_name");
        }

        return message;
    }
}
