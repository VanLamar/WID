﻿using UnityEngine;
using UnityEngine.UI;
using System.Linq;

[CreateAssetMenu(fileName = "Calendar", menuName = "Custom/Action/Calendar")]
public class Calendar : ActionP
{
    public string CalendarUIName = "kalandarUI";

    private GameObject calender;
    private GameObject today;
    private Transform originalParent;
    private int originalSiblingIndex;
    private readonly string[] keys = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
    [SerializeField] private bool isOpen = false;

    private void UpdateCalendarDayNames()
    {
       
    }

    public override void LoadResurces()
    {
        calender = SetUpWorld.Instance.ImportantObjects.FirstOrDefault(p => p.name == CalendarUIName);

        Transform todayTransform = calender.transform.GetChild(0);
        if (todayTransform != null)
            today = todayTransform.gameObject;

        Transform dayNamesTransform = calender.transform.Find("DayNames");
        if (dayNamesTransform != null)
        {
            for (int i = 0; i < dayNamesTransform.childCount; i++)
            {
                Transform child = dayNamesTransform.GetChild(i);
                Text text = child.GetComponent<Text>();
                if (text != null)
                    text.text = Localization.GetLocalizedString(keys[i]);
            }
        }
    }

    public override void Interaction(GameObject ActionObect)
    {
        if (isOpen) return; 

        isOpen = false;
        if (calender != null)
        {
            calender.SetActive(true);
            UpdateCalendarDayNames();
            if (today != null)
            {
                originalParent = today.transform.parent;
                originalSiblingIndex = today.transform.GetSiblingIndex();

                today.transform.parent = calender.transform.Find("NumbersOfDay").GetChild(parameters.Day);
            }
        }
    }



    public override void EndInteraction()
    {
        if (today != null && calender != null)
        {
            today.transform.SetParent(originalParent);
            today.transform.SetSiblingIndex(originalSiblingIndex);

            isOpen = false;
            calender.SetActive(false);
        }
    }

}
