﻿using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NPC", menuName = "Custom/NPC")]

public class NPCData : ScriptableObject
{
    [TextArea(2, 1)] public string Indexer = "NPC";
    public int Reputation = 0;
    public List<Sprite> NPCPortraits = new List<Sprite>();
    public List<ActionKeyExample> Keys = new List<ActionKeyExample>();
    public List<LangDialogue> UniqueDialogues;
    public List<TextAsset> ShownDialogues = new List<TextAsset>();
    public List<string> SavedKeys = new List<string>(); 
}

[System.Serializable]
public class LangDialogue
{
    public string key;
    public List<TextAsset> Dialogues = new List<TextAsset>();
}


[System.Serializable]
public class ActionKeyExample
{
    public string mainKey;
    public string[] needKeys;
    public int indexDialogue;
    public int priority = 0;
    public DialogueTriggerType dialogueTrigger = DialogueTriggerType.Immediately;
    public enum DialogueTriggerType
    {
        Immediately, AfterAllResponses, SaveCurrent
    }
}

