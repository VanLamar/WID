﻿using UnityEngine;

[System.Serializable]
public class SubLocation
{
    public string subLocationName;

    public Vector2 MinCameraPos;
    public Vector2 MaxCameraPos;
    public bool showBounds = false;
    public Vector2 MinBound;
    public Vector2 MaxBound;
}

