﻿using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Location", menuName = "Custom/Locations/Location")]
public class Location : ScriptableObject
{
    public string locationName;
    public List<SubLocation> subLocations = new List<SubLocation>();
}

