﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class Localization 
{
    private static Dictionary<string, string> localizedData = new Dictionary<string, string>();

    public static void LoadLocalizationFile(string languageCode, bool isFallback = false)
    {
        string filePath = Application.streamingAssetsPath + "/Language/Lang_" + languageCode + ".json";

        if (File.Exists(filePath))
        {
            string dataAsJson = File.ReadAllText(filePath);
            LocalizationData data = JsonUtility.FromJson<LocalizationData>(dataAsJson);

            localizedData = new Dictionary<string, string>();

            foreach (var entry in data.Localization)
                localizedData[entry.key] = entry.value;
        }
        else
        {
            Debug.LogError("Cannot find localization file for " + languageCode + "!");

            if (!isFallback)
                LoadLocalizationFile("en", true);
            else
                Debug.LogError("Fallback localization file (en) is also missing!");
        }
    }

    public static string GetLocalizedString(string key)
    {
        if (localizedData != null && localizedData.TryGetValue(key, out string value))
            return value;

        Debug.LogError($"Localization key '{key}' not found!");
        return "Localization_error01";
    }
}

[Serializable]
public class LocalizationData
{
    public List<LocalizationEntry> Localization;
}

[Serializable]
public class LocalizationEntry
{
    public string key;
    public string value;
}

