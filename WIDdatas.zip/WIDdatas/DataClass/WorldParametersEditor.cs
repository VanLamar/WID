﻿#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(WorldParameters))]
public class WorldParametersEditor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        WorldParameters myScript = (WorldParameters)target;

        if (GUILayout.Button("Reset Values"))
        {
            myScript.Day = 0;
            myScript.LangKey = "ph";
            myScript.Time = "";
            myScript.CatName = "";
            myScript.CanSleep = false;
            myScript.State = WorldParameters.TypeState.Day;
            myScript.DataPlayer = new PlayerData
            {
                MentalHealth = 100,
                CurrentLocation = "Home",
                CurrentSubLocation = "MyRoom",
                CurrentPossition = Vector2.zero,
                LastPossition = Vector2.zero,
                Gossips = false,
                Accessory = null,
                Hat = null
            };

            EditorUtility.SetDirty(myScript);
        }
    }
}
#endif
