﻿using UnityEngine;

[CreateAssetMenu(fileName = "Achievement", menuName = "Custom/Achievements")]
public class Achievement : ScriptableObject
{
    public string Id;
    [TextArea(3,3)]
    public string[] Name;
    [TextArea(3, 10)]
    public string[] Description; 
    public bool IsUnlocked;
    public int PointsRequired;
    public Sprite Icon;
}
