﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CatBehavior : MonoBehaviour
{
    [SerializeField] private List<CatSchedule> schedules = new List<CatSchedule>();
    [SerializeField] private bool isFacingRight = true;
    [SerializeField] private float speed = 5f;
    private CatSchedule currentSchedule;
    private int currentScheduleIndex = 0;
    private Animator anim;

    private void Start()
    {
        anim = GetComponent<Animator>();

        if (schedules.Count > 0)
        {
            currentSchedule = schedules[currentScheduleIndex];
            ExecuteSchedule();
        }
    }

    private void ExecuteSchedule()
    {
        if ((Vector2)transform.position != currentSchedule.position)
        {
            StartCoroutine(MoveToSchedulePosition());
        }
    }

    private IEnumerator MoveToSchedulePosition()
    {
        yield return MoveTo(currentSchedule.position);
        yield return new WaitForSeconds(currentSchedule.waitSecond);

        switch (currentSchedule.action)
        {
            case CatSchedule.CatAction.Play:
                // Trigger play behavior here
                break;
            case CatSchedule.CatAction.Sleep:
                anim.SetTrigger("Sleep");
                yield return new WaitForSeconds(currentSchedule.waitSecond);
                yield return MoveToNextSubLocation();
                anim.SetTrigger("Stop");
                break;
            case CatSchedule.CatAction.Drink:
                anim.SetTrigger("Sit");
                yield return new WaitForSeconds(currentSchedule.waitSecond);
                yield return MoveToNextSubLocation();
                anim.SetTrigger("Stop");
                break;
            case CatSchedule.CatAction.MoveOn:
            default:
                yield return MoveToNextSubLocation();
                break;
        }
    }

    private IEnumerator MoveToNextSubLocation()
    {
        if (currentSchedule.subLocation != schedules[(currentScheduleIndex + 1) % schedules.Count].subLocation)
        {
            yield return MoveTo(new Vector3(currentSchedule.door.gameObject.transform.position.x, currentSchedule.door.gameObject.transform.position.y - 4.51f, 0));
            transform.position = new Vector3(currentSchedule.nextDoor.gameObject.transform.position.x, currentSchedule.nextDoor.gameObject.transform.position.y - 4.51f, 0);
        }

        AdvanceSchedule();
        ExecuteSchedule();
    }


    private IEnumerator MoveTo(Vector2 destination)
    {
        while ((Vector2)transform.position != destination)
        {
            transform.position = Vector2.MoveTowards(transform.position, destination, Time.deltaTime * speed);
            CheckFlip(destination);
            yield return null;
        }
    }

    private void CheckFlip(Vector2 destination)
    {
        if ((destination.x < transform.position.x && isFacingRight) || (destination.x > transform.position.x && !isFacingRight))
            Flip();
    }

    private void Flip()
    {
        isFacingRight = !isFacingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }

    private void AdvanceSchedule()
    {
        currentScheduleIndex = (currentScheduleIndex + 1) % schedules.Count;
        currentSchedule = schedules[currentScheduleIndex];
    }
}

[System.Serializable]
public class CatSchedule
{
    public string subLocation;
    public Vector2 position;
    public Interaction door;
    public Interaction nextDoor;
    public CatAction action = CatAction.MoveOn;
    public float waitSecond = 0f; 

    public enum CatAction
    {
        MoveOn,
        Play,
        Sleep,
        Drink
    }
}
