﻿using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using static GameAPI;

public class NPC : MonoBehaviour
{
    public NPCData Myselfdata;
    public GameNPCData MyselfdataGame;
    public int index;

    [HideInInspector] public Dialogue Current;
    [SerializeField] private GameObject DialogueBox;

    public bool isCustom = true;
    private bool canInteract = false;
    private Dialogue savedDialogue = null;

    private SetUpWorld setUpWorld;

    private void Start()
    {
        setUpWorld = FindObjectOfType<SetUpWorld>();
        int index = Localization.LoadIndexDialogueLang();
        if (!isCustom && Myselfdata != null)
        {
            MyselfdataGame = ConvertToGameNPCData(Myselfdata);
            Current = FromJSON(MyselfdataGame.UniqueDialogues[index].Dialogues[0]);
        }
    }

    public virtual void ReceiveDialogueKeys()
    {
        foreach (var item in MyselfdataGame.Keys.OrderByDescending(k => k.priority))
        {
            var potentialDialogue = GetDialogueByKey(SetUpWorld.Instance.Parameters.LangKey)[item.indexDialogue];

            if (MyselfdataGame.ShownDialogues.Contains(potentialDialogue) && item.priority != 100)
                continue;

            if (MyselfdataGame.SavedKeys.Any(k => k == item.mainKey) && item.needKeys.Length <= 0)
            {
                HandleDialogueTrigger(item, potentialDialogue);
                break;
            }
            else if (MyselfdataGame.SavedKeys.Any(k => k == item.mainKey) && item.needKeys.All(nk => MyselfdataGame.SavedKeys.Any(k => k == nk)) && item.needKeys.Length >= 0)
            {
                HandleDialogueTrigger(item, potentialDialogue);
                break;
            }
        }
    }

    private void HandleDialogueTrigger(ActionKeyExample keyItem, TextAsset potentialDialogue)
    {
        switch (keyItem.dialogueTrigger)
        {
            case ActionKeyExample.DialogueTriggerType.Immediately:
                Current = FromJSON(potentialDialogue);
                if (keyItem.priority != 100)
                    MyselfdataGame.ShownDialogues.Add(potentialDialogue);
                break;

            case ActionKeyExample.DialogueTriggerType.AfterAllResponses:
                if (Current.Dialogues[0].PlayerResponses.Count == 0)
                {
                    Current = FromJSON(potentialDialogue);
                    if (keyItem.priority != 100)
                        MyselfdataGame.ShownDialogues.Add(potentialDialogue);
                }
                break;

            case ActionKeyExample.DialogueTriggerType.SaveCurrent:
                savedDialogue = Current;
                Current = FromJSON(potentialDialogue);
                if (keyItem.priority != 100)
                    MyselfdataGame.ShownDialogues.Add(potentialDialogue);
                break;
        }
    }


    private void Update()
    {
        if (canInteract && Input.GetKeyDown(KeyCode.E))
            StartDialogueWithNPC();
    }

    public Dialogue ConvertToDoalog(GameNPCData f)
    {
        return FromJSON(f.UniqueDialogues[index].Dialogues[0]);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canInteract = true;
            if (DialogueBox != null)
            {
                DialogueBox.SetActive(canInteract);
                DialogueBox.transform.position = new Vector3(transform.position.x + -1, transform.position.y +2);
            }
        }
    }

    private GameNPCData ConvertToGameNPCData(NPCData npcData)
    {
        GameNPCData gameData = new GameNPCData();

        gameData.Indexer = npcData.Indexer;
        gameData.Reputation = npcData.Reputation;
        gameData.NPCPortraits = npcData.NPCPortraits;
        gameData.Keys = npcData.Keys;
        gameData.UniqueDialogues = npcData.UniqueDialogues;
        gameData.ShownDialogues = npcData.ShownDialogues;
        gameData.SavedKeys = npcData.SavedKeys;

        return gameData;
    }


    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canInteract = false;
            if (DialogueBox != null)
            {
                DialogueBox.SetActive(canInteract);
            }
        }
    }

    private void StartDialogueWithNPC()
    {
        var DM = FindObjectOfType<DialogueManager>();
        PickDialogue();
        if (!DM.isTalking)
        {
            DM.StartDialogue(Current, MyselfdataGame.NPCPortraits, this);
            if (savedDialogue != null)
            {
                Current = savedDialogue;
                savedDialogue = null;
            }
        }

        if (DialogueBox != null)
        {
            DialogueBox.SetActive(false);
        }
    }


    private void PickDialogue()
    {
        int index = Localization.LoadIndexDialogueLang();

        if (MyselfdataGame.SavedKeys.Count == 0)
        {
            if (Current.Dialogues.Count >= 1)
                return;

            Current = FromJSON(MyselfdataGame.UniqueDialogues[index].Dialogues[0]);
            return;
        }

        ReceiveDialogueKeys();

    }

    public static Dialogue FromJSON(TextAsset json)
    {
        return JsonUtility.FromJson<Dialogue>(json.text);
    }

    private List<TextAsset> GetDialogueByKey(string key)
    {
        foreach (LangDialogue langDialogue in MyselfdataGame.UniqueDialogues)
        {
            if (langDialogue.key == key)
                return langDialogue.Dialogues;
        }

        Debug.LogWarning("Dialogue lang " + key + " not found!");
        return null;
    }
}
