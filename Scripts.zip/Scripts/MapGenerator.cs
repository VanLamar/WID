﻿using UnityEngine;

public class MapGenerator : MonoBehaviour
{
    private const char WALL_SYMBOL = '#';
    private const char PLAYER_SYMBOL = '@';

    [SerializeField] private GameObject wallPrefab;
    [SerializeField] private GameObject playerPrefab;
    [SerializeField] private TextAsset mapText;

    void Start()=>
        GenerateMapFromText();

    private void GenerateMapFromText()
    {
        string[] lines = mapText.text.Split('\n');
        for (int y = 0; y < lines.Length; y++)
        {
            ProcessLine(lines[y], y);
        }
    }

    private void ProcessLine(string line, int y)
    {
        for (int x = 0; x < line.Length; x++)
        {
            Vector3 position = new Vector3(x, -y, 0);
            CreatePrefabFromSymbol(line[x], position);
        }
    }

    private void CreatePrefabFromSymbol(char symbol, Vector3 position)
    {
        switch (symbol)
        {
            case WALL_SYMBOL:
                Instantiate(wallPrefab, position, Quaternion.identity);
                break;
            case PLAYER_SYMBOL:
                Instantiate(playerPrefab, position, Quaternion.identity);
                break;
        }
    }
}
