﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ClothsetLogic : MonoBehaviour
{
    [SerializeField] private bool isOpenUI = false;
    [SerializeField] private List<Item> itemsInClothset = new List<Item>();
    [SerializeField] private GameObject inventotyPanel;
    [SerializeField] private Transform contentInventory;
    [SerializeField] private Transform contentClothset;
    [SerializeField] private GameObject prefabSlot;
    [SerializeField] private Text[] labbelTexts;
    private Animator anim;
    private Inventory inventory;
    private bool playerVisibility = true;
    private WorldParameters parameters => WorldParameters.Instance;

    private void Start()
    {
        inventory = FindObjectOfType<Inventory>();
        anim = GetComponent<Animator>();

        Localization.LoadLocalizationFile(parameters.LangKey);
        labbelTexts[0].text = Localization.GetLocalizedString("labbelClothset");
        labbelTexts[1].text = Localization.GetLocalizedString("labbelInventory");
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            if (Input.GetKeyDown(KeyCode.E))
                anim.SetBool("Open", true);

            if (Input.GetKeyDown(KeyCode.E) && parameters.State == WorldParameters.TypeState.Night)
                inventory.gameObject.SetActive(true);
        }
    }


    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player") && parameters.State == WorldParameters.TypeState.Day)
            anim.SetBool("Open", false);
    }


    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.E) && parameters.State == WorldParameters.TypeState.Night && !playerVisibility)
        {
            inventory.gameObject.SetActive(true);
            playerVisibility = true;
        }
    }

    private void LoadInventoryItems()
    {
        DestroyChildren(contentInventory);
        DestroyChildren(contentClothset);

        foreach (Item item in inventory.CurrentItems())
        {
            if (item.Itemtype == Item.TypeItem.Cloth)
                CreateSlot(item, contentInventory);
        }

        foreach (Item item in itemsInClothset)
            CreateSlot(item, contentClothset);
    }

    private void CreateSlot(Item item, Transform parent)
    {
        GameObject newSlot = Instantiate(prefabSlot, parent);
        Text buttonText = newSlot.transform.GetChild(0).GetComponent<Text>();
        Button button = newSlot.GetComponent<Button>();

        buttonText.text = "* " + item.Name[Localization.LoadIndexDialogueLang()];
        button.onClick.AddListener(() => MoveToContent(newSlot, parent == contentInventory ? contentClothset : contentInventory, item));
    }

    private void MoveToContent(GameObject slot, Transform newParent, Item item)
    {
        GameObject newSlot = Instantiate(slot, newParent);
        Button button = newSlot.GetComponent<Button>();

        button.onClick.RemoveAllListeners();
        Destroy(slot);
        button.onClick.AddListener(() => MoveToContent(newSlot, newParent == contentInventory ? contentClothset : contentInventory, item));

        if (newParent == contentClothset)
        {
            inventory.RemoveItemFromMain(item);
            itemsInClothset.Add(item);
        }
        else
        {
            inventory.AddItem(item);
            itemsInClothset.Remove(item);
        }
    }

    private void DestroyChildren(Transform parent)
    {
        for (int i = 0; i < parent.childCount; i++)
            Destroy(parent.GetChild(i).gameObject);
    }


    public void SwitchPanel()
    {
        AnimatorStateInfo stateInfo = anim.GetCurrentAnimatorStateInfo(0);
        if (parameters.State == WorldParameters.TypeState.Day)
        {
            LoadInventoryItems();

            isOpenUI = !isOpenUI;
            inventotyPanel.SetActive(isOpenUI);
        }
        else
        {
            if (stateInfo.IsName("Close"))
            {
                playerVisibility = !playerVisibility;
                inventory.gameObject.SetActive(playerVisibility);
            }

            anim.SetBool("Open", false);
        }
    }
}
