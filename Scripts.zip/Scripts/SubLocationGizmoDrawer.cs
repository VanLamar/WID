﻿#if UNITY_EDITOR
using UnityEngine;

public class SubLocationGizmoDrawer : MonoBehaviour
{
    [SerializeField] private Location location;

    private void OnDrawGizmos()
    {
        if (location == null) return;

        foreach (var subLocation in location.subLocations)
        {
            if (subLocation != null && subLocation.showBounds)
            {
                Gizmos.color = Color.red;

                Vector2 center = (subLocation.MinBound + subLocation.MaxBound) * 0.5f;
                Vector2 size = subLocation.MaxBound - subLocation.MinBound;
                Gizmos.DrawWireCube(new Vector3(center.x, center.y, 0), new Vector3(size.x, size.y, 0));
            }
        }
    }

}
#endif
