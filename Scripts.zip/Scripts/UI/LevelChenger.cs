﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelChenger : MonoBehaviour
{
    public static LevelChenger Instance;
    public TypeLevel typeLevel = TypeLevel.Location;
    public enum TypeLevel { Location, SubLocation }
    public string levelToLoad;
    public Vector3 possition;
    private Animator anim;

    private void Start()
    {
        anim = GetComponent<Animator>();
        Instance = this;
        anim.SetBool("Loading", false);
    }
    public void FadeToLevel()
    {
        anim.SetBool("Loading", true);
    }
    public void FadeComplete()
    {
        switch (typeLevel)
        {
            case TypeLevel.Location:
                SceneManager.LoadScene(levelToLoad);
                break;
            case TypeLevel.SubLocation:
                GameObject.FindGameObjectWithTag("Player").transform.position = possition;
                anim.SetBool("Loading", false);
                break;
        }
    }
}
