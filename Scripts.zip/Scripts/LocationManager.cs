﻿using UnityEngine;

public class LocationManager : MonoBehaviour
{
    public SubLocation currentSubLocation;
    [SerializeField] private Location location;

    private Transform playerTransform;
    private WorldParameters parameters => WorldParameters.Instance;

    private void Start()
    {
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
        parameters.DataPlayer.CurrentLocation = location.locationName;
        print(location.subLocations[0].MaxBound + " - " + location.subLocations[0].MinBound);
    }

    bool IsInsideBounds(Vector2 position, SubLocation subLocation)
    {
        return position.x >= subLocation.MinBound.x && position.x <= subLocation.MaxBound.x &&
               position.y >= subLocation.MinBound.y && position.y <= subLocation.MaxBound.y;
    }

    private void Update()
    {
        if (playerTransform == null)
        {
            Debug.LogWarning("Player transform is not set in LocationManager");
            return;
        }

        Vector2 playerPos = new Vector2(playerTransform.position.x, playerTransform.position.y);

        if (currentSubLocation != null)
        {
            if (IsInsideBounds(playerPos, currentSubLocation))
                return;
            else
                currentSubLocation = null;
        }

        foreach (SubLocation subLoc in location.subLocations)
        {
            if (IsInsideBounds(playerPos, subLoc))
            {
                currentSubLocation = subLoc;
                parameters.DataPlayer.CurrentSubLocation = subLoc.subLocationName;
                Debug.Log($"Player is in location: {location.locationName}, sublocation: {subLoc.subLocationName}");
                return;
            }
            
        }
    }
}
