﻿using UnityEngine;

public class Nightlight : MonoBehaviour
{
    [SerializeField] private Sprite[] appearances;
    [SerializeField] private TextAsset[] monologues;

    private bool canInteract = false;
    private bool isActive = false;
    private DialogueManager _dialogueManager;
    private SpriteRenderer _rendererAppearance;
    private GameObject _light;

    private void Start()
    {
        _dialogueManager = FindObjectOfType<DialogueManager>();
        _rendererAppearance = GetComponent<SpriteRenderer>();
        _light = transform.GetChild(0).gameObject;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
            canInteract = true;
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
            canInteract = false;
    }

    private void Update()
    {
        if (canInteract)
        {
            if (Input.GetKeyDown(KeyCode.E))
                Interaction();
        }
    }

    private void Interaction()
    {
        if (_dialogueManager.isTalking)
            return;

        if (!WorldParameters.Instance.CanSleep)
        {
            _dialogueManager.StartMonologue(JsonUtility.FromJson<Dialogue>(monologues[Localization.LoadIndexDialogueLang()].text));
            return;
        }
        
        isActive = !isActive;

        if (isActive)
            _rendererAppearance.sprite = appearances[1];
        else
            _rendererAppearance.sprite = appearances[0];

        _light.SetActive(isActive);
    }
}
