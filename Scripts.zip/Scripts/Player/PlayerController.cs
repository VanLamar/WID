﻿using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public bool CanMove = true;
    [SerializeField] private float moveSpeed = 5f;

    private Rigidbody2D rb;
    private Vector2 movement;
    private bool isFacingRight = false;


    private void Start()=>
        rb = GetComponent<Rigidbody2D>();

    private void FixedUpdate()
    {
        if (CanMove)
            rb.MovePosition(rb.position + movement * moveSpeed * Time.fixedDeltaTime);
    }

    private void Flip()
    {
        isFacingRight = !isFacingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }

    private void Update()
    {
        if (!CanMove)
            return;

        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");
        movement = movement.normalized;

        if (movement.x > 0f && !isFacingRight)
            Flip();
        else if (movement.x < 0f && isFacingRight)
            Flip();
    }
}
