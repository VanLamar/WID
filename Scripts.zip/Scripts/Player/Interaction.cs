﻿using UnityEngine;

public class Interaction : MonoBehaviour
{
    [SerializeField] private ActionP action;
    private bool canInteract = false;

    private void Start()
    {
        action.LoadResurces();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
            canInteract = true;
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            EndInteraction();
        }
    }

    private void EndInteraction()
    {
        action.EndInteraction();
        canInteract = false;
    }

    private void Update()
    {
        if (canInteract)
        {
            if (Input.GetKeyDown(action.ButtonUse))
            {
                action.Interaction(gameObject);
                print($"I've interacted with {action.Name}");
            }
            action.ChechInteraction(gameObject);
        }
    }
}
