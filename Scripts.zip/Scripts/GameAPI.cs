﻿using UnityEngine;
using System.IO;
using System.IO.Pipes;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Linq;

public class GameAPI : MonoBehaviour
{
    public string NameMod { get; set; }
    public List<GameObject> ObjectScript = new List<GameObject>();

    private string DirectoryImages = "/assets/";
    private string DirectoryFiles = "/assets/";
    private string modsDirectory = Application.streamingAssetsPath + "/Mods/";

    public virtual void Loop() { }
    public virtual void Initialization() { }

    private void Start()
    {
        StartCoroutine(CheckForNewMods());

        using (var pipeServer = new NamedPipeServerStream("WIDServer", PipeDirection.In))
        {
            //Console.WriteLine("NamedPipeServer is waiting for a connection...");
            pipeServer.WaitForConnection();

            using (var reader = new StreamReader(pipeServer))
            {
                string message = reader.ReadLine();
            }
        }
    }


    private void Update()
    {
        Loop();
    }

    private IEnumerator CheckForNewMods()
    {
        while (true)
        {
            string[] modFiles = Directory.GetFiles(modsDirectory, "*.mod");
            foreach (string modFilePath in modFiles)
            {
                string modFileName = Path.GetFileNameWithoutExtension(modFilePath);
                string modName = modFileName.Split('_')[0];

                byte[] compiledBytes = File.ReadAllBytes(modFilePath);
                LoadAndExecuteAssembly(compiledBytes, modName);
                File.Delete(modFilePath);
            }
            yield return new WaitForSeconds(5);
        }
    }

    public void LoadAndExecuteAssembly(byte[] assemblyBytes, string modName)
    {
        Assembly assembly = Assembly.Load(assemblyBytes);
        if (assembly != null)
        {
            Type gameApiType = typeof(GameAPI);
            IEnumerable<Type> targetTypes = assembly.GetTypes().Where(t => t.IsSubclassOf(gameApiType));

            foreach (Type targetType in targetTypes)
            {
                GameObject modObject = new GameObject(targetType.Name);
                GameAPI userScript = (GameAPI)modObject.AddComponent(targetType);
                userScript.NameMod = modName;
                userScript.Initialization();
            }
        }
    }


    public Sprite LoadSpriteFromPath(string path)
    {
        string newPath = $"{modsDirectory}{NameMod}{DirectoryImages}{path}";
        if (File.Exists(newPath))
        {
            byte[] fileData = File.ReadAllBytes(newPath);
            Texture2D texture = new Texture2D(2, 2);
            if (texture.LoadImage(fileData))
            {
                return Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f)); 
            }
        }
        return null;
    }

    public TextAsset LoadTextAssetFromPath(string path)
    {
        string newPath = $"{modsDirectory}{NameMod}{DirectoryFiles}{path}";
        if (File.Exists(newPath))
        {
            string fileContent = File.ReadAllText(newPath);
            return new TextAsset(fileContent);
        }
        return null;
    }


    public void CreateNpc(GameNPC npcData)
    {
        GameObject npcObject = new GameObject(npcData.name);
        SpriteRenderer spriteRenderer = npcObject.AddComponent<SpriteRenderer>();
        BoxCollider2D boxCollider = npcObject.AddComponent<BoxCollider2D>();
        NPC npc = npcObject.AddComponent<NPC>();
        GameNPCData npcInfo = new GameNPCData();

        npcObject.transform.position = npcData.position;
        npcObject.transform.localScale = npcData.scale;
        spriteRenderer.sprite = LoadSpriteFromPath(npcData.path);

        boxCollider.isTrigger = true; 

        if (spriteRenderer.sprite != null)
        {
            boxCollider.size = spriteRenderer.sprite.bounds.size;

            boxCollider.size *= 1.1f;
        }

        npcInfo.Indexer = npcData.name;

        for (int i = 0; i < npcData.pathPortraits.Count; i++)
            npcInfo.NPCPortraits.Add(LoadSpriteFromPath(npcData.pathPortraits[i]));

        if (npcData.pathDialogues.Count == npcData.pathDialoguesLangs.Count)
        {
            for (int i = 0; i < npcData.pathDialogues.Count; i++)
            {
                LangDialogue langDialogue = new LangDialogue();
                langDialogue.key = npcData.pathDialoguesLangs[i];

                TextAsset textAsset = LoadTextAssetFromPath(npcData.pathDialogues[i]);
                if (textAsset != null)
                    langDialogue.Dialogues.Add(textAsset);

                npcInfo.UniqueDialogues.Add(langDialogue);
            }
        }

        npc.MyselfdataGame = npcInfo;
        npc.Current = npc.ConvertToDoalog(npcInfo);
        ObjectScript.Add(npcObject);
    }

    public void CreateAchievement(GameAchievement achievementData)
    {
        Achievement newAchiev = new Achievement();
        newAchiev.Description = achievementData.Description;
        newAchiev.Name = achievementData.Name;
        newAchiev.Icon = LoadSpriteFromPath(achievementData.PathIcon);
        newAchiev.IsUnlocked = achievementData.IsUnlocked;
        newAchiev.PointsRequired = achievementData.PointsRequired;
    }

    public GameObject GetObjectScriptByIndex(int index)
    {
        return ObjectScript[index];
    }

    public void GetAchievement(string Indexer) =>
        AchievementManager.Instance.CheckAchievement(Indexer, 100);
}


[Serializable]
public class GameNPC
{
    public string name;
    public string location;
    public string path;
    public Vector3 position;
    public Vector3 scale = new Vector3(1, 1, 1);
    public List<string> pathPortraits;
    public List<string> pathDialogues;
    public List<string> pathDialoguesLangs;

    public GameNPC(string Name, string Location)
    {
        name = Name;
        location = Location;
    }
}


[Serializable]
public class GameNPCData
{
    public string Indexer = "NPC";
    public int Reputation = 0;
    public List<Sprite> NPCPortraits = new List<Sprite>();
    public List<ActionKeyExample> Keys = new List<ActionKeyExample>();
    public List<LangDialogue> UniqueDialogues = new List<LangDialogue>();
    public List<TextAsset> ShownDialogues = new List<TextAsset>();
    public List<string> SavedKeys = new List<string>();
}


[Serializable]
public class WIDConsole
{
    private static string logFilePath = Application.streamingAssetsPath + "/Mods/console.log";
    public static void Print(string text)
    {
        if (File.Exists(logFilePath))
        {
            string currentContent = File.ReadAllText(logFilePath);
            if (string.IsNullOrEmpty(currentContent) || currentContent != text)
            {
                File.WriteAllText(logFilePath, text);
            }
        }
        else
        {
            File.WriteAllText(logFilePath, text);
        }
    }

    public static void PrintError(string text)
    {
        Print(text + " $r");
    }
}

[Serializable]
public class GameAchievement
{
    public string Id;
    public string[] Name;
    public string[] Description;
    public bool IsUnlocked;
    public int PointsRequired;
    public string PathIcon;
}