﻿using UnityEngine;

//[CreateAssetMenu(fileName = "NoneItem", menuName = "Custom/Item")]
public class Item : ScriptableObject
{
    public int ID;
    public int Quantity = 1;
    [TextArea(3, 5)]public string[] Name;
    [TextArea(3, 10)]public string[] Description;
    [HideInInspector]public Inventory inventory;
    public Sprite Icon;
    public TypeItem Itemtype = TypeItem.Default;
    public enum TypeItem { Cloth, Default }

    public virtual void UseItem(int uniqueID)
    {
        inventory = FindObjectOfType<Inventory>();
        if (inventory.IsInMainInventory(uniqueID))
        {
            inventory.MoveToControl(uniqueID);
            inventory.HideInventory();
        }
        else if (inventory.IsInControlInventory(uniqueID))
        {
            UseItemControl(uniqueID);
        }
    }

    public virtual void UseItemControl(int uniqueID) =>
        FindObjectOfType<Inventory>().RemoveItem(uniqueID);
}


[System.Serializable]
public class InventorySlot
{
    public GameObject SlotObject { get; private set; }
    public Item ContainedItem { get; private set; }
    public int UniqueID { get; private set; }

    public InventorySlot(GameObject slotObject, int uniqueID)
    {
        SlotObject = slotObject;
        UniqueID = uniqueID;
    }

    public void SetItem(Item item)
    {
        ContainedItem = item;
        SlotObject.GetComponent<ItemUI>().item = item;
        SlotObject.GetComponent<ItemUI>().id = UniqueID;
        SlotObject.GetComponent<ItemUI>().SetUp();
    }

    public void ClearItem()=>
        ContainedItem = null;
}
