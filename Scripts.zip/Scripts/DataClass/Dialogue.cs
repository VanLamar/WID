﻿using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Dialogue
{
    public string NPCName;
    public List<DialogueData> Dialogues;

    [System.Serializable]
    public class Response
    {
        [TextArea(3, 10)]
        public string ResponseTextKey;
        public string NextDialogueID; 
        public string TriggerKey;
        public int FriendshipPoints;
    }

    [System.Serializable]
    public class DialogueData
    {
        public string Id; 
        [TextArea(3, 10)]
        public string InitialPhrase;
        public List<Response> PlayerResponses;
    }
}
