﻿using UnityEngine;

[CreateAssetMenu(fileName = "Door", menuName = "Custom/Action/Door")]
public class Door : ActionP
{
    public TypeDoor DoorType = TypeDoor.Open;
    public TypeDoorOpen DoorTypeOpen = TypeDoorOpen.Location;
    public int IndexChild = 1;
    public Vector3 possitionNextDoor;
    public int MaxKnocks = 5;
    public string Location;

    public TextAsset[] monologues;
    public AudioClip KnockKnockAudio;
    public AudioClip OpenDoorAudio;
    public enum TypeDoor { Open, Locked }
    public enum TypeDoorOpen { Location, SubLocation }

    private int CurrentKnocks = 0;
    private bool CanKnoking = true;


    public override void Interaction(GameObject ActionObect) 
    {
        switch (DoorType)
        {
            case TypeDoor.Open:
                OpenDoor(ActionObect);
                Debug.Log("Exit");
                break;
            case TypeDoor.Locked:
                Knocking(ActionObect);
                break;
        }
    }

    private void OpenDoor(GameObject ActionObect)
    {
        AudioSource AU = ActionObect.GetComponent<AudioSource>();
        AU.clip = OpenDoorAudio;
        AU.Play();

        switch (DoorTypeOpen)
        {
            case TypeDoorOpen.Location:
                LevelChenger.Instance.typeLevel = LevelChenger.TypeLevel.Location;
                LevelChenger.Instance.levelToLoad = Location;
                parameters.DataPlayer.CurrentLocation = Location;
                LevelChenger.Instance.FadeToLevel();
                break;
            case TypeDoorOpen.SubLocation:
                LevelChenger.Instance.typeLevel = LevelChenger.TypeLevel.SubLocation;
                LevelChenger.Instance.possition = possitionNextDoor;
                LevelChenger.Instance.FadeToLevel();
                break;
        }
    }

    private void Knocking(GameObject ActionObect)
    {
        if (CurrentKnocks >= MaxKnocks)
        {
            if (!dialogueManager.isTalking)
                dialogueManager.StartMonologue(JsonUtility.FromJson<Dialogue>(monologues[Localization.LoadIndexDialogueLang()].text));

            CurrentKnocks = 0;
            CanKnoking = false;
        }

        if (CanKnoking)
        {
            AudioSource AU = ActionObect.GetComponent<AudioSource>();
            AU.clip = KnockKnockAudio;
            AU.Play();
            CurrentKnocks++;
        }
    }

    public override void EndInteraction() 
    {
        CurrentKnocks = 0;
        CanKnoking = true;
    }

}
