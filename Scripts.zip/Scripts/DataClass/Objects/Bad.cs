﻿using UnityEngine;
using UnityEngine.SceneManagement;

[CreateAssetMenu(fileName = "Bad", menuName = "Custom/Action/Bad")]
public class Bad : ActionP
{
    public string NameScene;
    public TextAsset[] monologues;

    private void StartMessage()
    {
        if (!dialogueManager.isTalking)
            dialogueManager.StartMonologue(JsonUtility.FromJson<Dialogue>(monologues[Localization.LoadIndexDialogueLang()].text));
    }


    public override void Interaction(GameObject ActionObect)
    {
        if (parameters.CanSleep == true)
        {
            parameters.Day++;
            parameters.State = WorldParameters.TypeState.Night;
            parameters.DataPlayer.CurrentLocation = SceneManager.GetActiveScene().name;
            parameters.DataPlayer.CurrentPossition = Player.transform.position;

            LevelChenger.Instance.levelToLoad = NameScene;
            LevelChenger.Instance.FadeToLevel();
        }
        else
        {
            StartMessage();
        }
    }

    public override void EndInteraction()
    {
        base.EndInteraction();
    }
}
