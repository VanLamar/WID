﻿using System.Collections.Generic;
using UnityEngine;

public class ActionP : ScriptableObject
{
    public string Name;
    public KeyCode ButtonUse = KeyCode.E;
    public WorldParameters parameters => WorldParameters.Instance;
    public DialogueManager dialogueManager => FindObjectOfType<DialogueManager>();
    public GameObject Player => FindObjectOfType<PlayerController>().gameObject;

    public virtual void Interaction(GameObject ActionObect){}
    public virtual void EndInteraction(){}
    public virtual void LoadResurces() { }
    public virtual void ChechInteraction(GameObject ActionObect){}

    private Dictionary<string, GameObject> cachedObjects = new Dictionary<string, GameObject>();

    public GameObject FindInactiveObjectByName(string objectName)
    {
        if (cachedObjects.ContainsKey(objectName))
        {
            return cachedObjects[objectName];
        }

        GameObject[] allObjects = UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects();
        foreach (GameObject obj in allObjects)
        {
            Transform foundTransform = obj.transform.Find(objectName);
            if (foundTransform != null)
            {
                cachedObjects[objectName] = foundTransform.gameObject;
                return foundTransform.gameObject;
            }
        }
        return null;
    }
}
