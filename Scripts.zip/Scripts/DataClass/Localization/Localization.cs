﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class Localization 
{
    private static Dictionary<string, string> localizedData = new Dictionary<string, string>();

    public static void LoadLocalizationFile(string languageCode, bool isFallback = false)
    {
        string filePath = Application.streamingAssetsPath + "/Language/Lang_" + languageCode + ".json";

        if (File.Exists(filePath))
        {
            string dataAsJson = File.ReadAllText(filePath);
            LocalizationData data = JsonUtility.FromJson<LocalizationData>(dataAsJson);

            localizedData = new Dictionary<string, string>();

            foreach (var entry in data.Localization)
                localizedData[entry.key] = entry.value;
        }
        else
        {
            Debug.LogError("Cannot find localization file for " + languageCode + "!");

            if (!isFallback)
                LoadLocalizationFile("en", true);
            else
                Debug.LogError("Fallback localization file (en) is also missing!");
        }
    }

    public static string GetLocalizedString(string key)
    {
        if (localizedData != null && localizedData.TryGetValue(key, out string value))
            return value;

        Debug.LogError($"Localization key '{key}' not found!");
        return "Localization_error01";
    }

    public static int LoadIndexDialogueLang()
    {
        LanguageData languageData = LoadLanguageData();
        if (languageData != null && languageData.languages != null)
        {
            string currentLangKey = WorldParameters.Instance.LangKey;
            for (int i = 0; i < languageData.languages.Length; i++)
            {
                if (languageData.languages[i] == currentLangKey)
                {
                    return i;
                }
            }
        }

        Debug.LogError("Language key not found or languages not loaded.");
        return 0;
    }


    public static LanguageData LoadLanguageData()
    {
        string filePath = Application.streamingAssetsPath + "/Language/Langs.json";
        try
        {
            if (File.Exists(filePath))
            {
                string jsonData = File.ReadAllText(filePath);
                return JsonUtility.FromJson<LanguageData>(jsonData);
            }
            else
            {
                Debug.LogError("File not found: " + filePath);
                return null;
            }
        }
        catch (Exception ex)
        {
            Debug.LogError("Error loading language data: " + ex.Message);
            return null;
        }
    }
}

[Serializable]
public class LocalizationData
{
    public List<LocalizationEntry> Localization;
}

[Serializable]
public class LanguageData
{
    public string[] languages;
}


[Serializable]
public class LocalizationEntry
{
    public string key;
    public string value;
}