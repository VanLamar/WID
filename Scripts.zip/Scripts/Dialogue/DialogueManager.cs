﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;

public class DialogueManager : MonoBehaviour
{
    public bool isTalking = false;
    [SerializeField] private Text NPCNameText;
    [SerializeField] private Image NPCPortrait;
    [SerializeField] private Text DialogueText;
    [SerializeField] private Button ContinueButton;
    [SerializeField] private GameObject DialoguePanel;
    [SerializeField] private GameObject ResponseButtonPrefab;
    [SerializeField] private Transform ResponseButtonContainer;

    private Dialogue.DialogueData currentDialogueData;
    private Dialogue currentDialogue;
    private Coroutine currentCoroutine;
    private PlayerController player;
    private string patternWithNumber = @"\[(p|i)(\d+)\]";
    private string patternWithoutNumber = @"\[(c|d|e)\]"; 
    private bool isWriting;

    private NPC npc;
    private List<Sprite> portraits = new List<Sprite>();
    private List<string> strings = new List<string>();
    private List<string> textSegments = new List<string>();
    private int currentTextIndex = 0;
    private int maxCharactersInSegment = 388;
    private WorldParameters Parameters => WorldParameters.Instance;


    private void Start()
    {
        player = FindObjectOfType<PlayerController>();
    }

    private void Update()
    {
        if (isWriting || !isTalking) return;

        if (Input.GetKey(KeyCode.Return))
            ContinueDialogue();

        if (currentDialogueData?.PlayerResponses?.Count > 0)
        {
            for (int i = 1; i <= currentDialogueData.PlayerResponses.Count; i++)
            {
                if (Input.GetKeyDown(i.ToString()))
                {
                    HandleResponse(i - 1);
                    break;
                }
            }
        }
    }


    public void StartDialogue(Dialogue assets, List<Sprite> sprites, NPC current)
    {
        isTalking = true;
        currentDialogue = assets;
        currentDialogueData = currentDialogue.Dialogues.Find(d => d.Id == "Start");
        npc = current;

        NPCPortrait.gameObject.SetActive(true);
        portraits = sprites;
        DialoguePanel.SetActive(true);
        NPCNameText.text = currentDialogue.NPCName;
        NPCPortrait.sprite = sprites[0];
        ContinueButton.gameObject.SetActive(false);

        StopAllCoroutines();
        currentCoroutine = StartCoroutine(WriteText(currentDialogueData.InitialPhrase));
        player.CanMove = false;
    }

    public void StartMonologue(Dialogue assets)
    {
        isTalking = true;
        currentDialogue = assets;
        currentDialogueData = currentDialogue.Dialogues.Find(d => d.Id == "Start");

        NPCPortrait.gameObject.SetActive(false);
        DialoguePanel.SetActive(true);
        NPCNameText.text = currentDialogue.NPCName;
        ContinueButton.gameObject.SetActive(false);

        StopAllCoroutines();
        currentCoroutine = StartCoroutine(WriteText(currentDialogueData.InitialPhrase));
        player.CanMove = false;
    }

    private void HandleResponse(int responseIndex)
    {
        Dialogue.Response response = currentDialogueData.PlayerResponses[responseIndex];
        currentDialogueData = currentDialogue.Dialogues.Find(d => d.Id == response.NextDialogueID);
        if (response.TriggerKey.Length != 0 && response.TriggerKey != "Me" && response.TriggerKey != "Thoughts")
            strings.Add(response.TriggerKey);

        npc.Myselfdata.Reputation += response.FriendshipPoints;

        currentDialogueData.PlayerResponses.Remove(response);
        currentDialogue.Dialogues[0].PlayerResponses.Remove(response);
        npc.Current = currentDialogue;

        ContinueButton.gameObject.SetActive(false);
        DialogueText.gameObject.SetActive(true);
        NPCPortrait.gameObject.SetActive(true);
        NPCNameText.gameObject.SetActive(true);
        DeleteOldButtons();

        if (currentCoroutine != null)
            StopCoroutine(currentCoroutine);

        currentCoroutine = StartCoroutine(WriteText(currentDialogueData.InitialPhrase));

        switch (response.TriggerKey)
        {
            case "Thoughts":
                NPCNameText.text = "";
                NPCPortrait.gameObject.SetActive(false);
                return;

            case "Me":
                NPCNameText.text = "???";
                NPCPortrait.gameObject.SetActive(true);
                break;

            default:
                NPCNameText.text = currentDialogue.NPCName;
                NPCPortrait.gameObject.SetActive(true);
                break;
        }

    }

    private IEnumerator WriteText(string text)
    {
        text = ParseText(text);
        textSegments = SplitTextIntoSegments(text, maxCharactersInSegment);

        isWriting = true;
        DialogueText.text = "";
        foreach (char c in textSegments[currentTextIndex])
        {
            DialogueText.text += c;
            yield return null;
        }
        isWriting = false;
        ContinueButton.gameObject.SetActive(true);
    }

    private List<string> SplitTextIntoSegments(string text, int maxCharacters)
    {
        List<string> segments = new List<string>();
        for (int i = 0; i < text.Length; i += maxCharacters)
        {
            int length = Math.Min(maxCharacters, text.Length - i);
            segments.Add(text.Substring(i, length));
        }
        ContinueButton.gameObject.SetActive(true);
        return segments;
    }

    public void ContinueDialogue()
    {
        if (isWriting)
            return;

        if (currentTextIndex < textSegments.Count - 1)
        {
            currentTextIndex++;
            ContinueButton.gameObject.SetActive(false);
            currentCoroutine = StartCoroutine(WriteText(currentDialogueData.InitialPhrase));
            return;
        }

        if (currentDialogueData.PlayerResponses.Count == 0)
        {
            EndDialogue();
            return;
        }

        DeleteOldButtons();

        for (int i = 0; i < currentDialogueData.PlayerResponses.Count; i++)
        {
            int index = i;
            Button button = Instantiate(ResponseButtonPrefab, ResponseButtonContainer).GetComponent<Button>();
            button.GetComponentInChildren<Text>().text = currentDialogueData.PlayerResponses[i].ResponseTextKey;
            button.onClick.AddListener(() => HandleResponse(index));
        }
        DialogueText.gameObject.SetActive(false);
        NPCPortrait.gameObject.SetActive(false);
        NPCNameText.gameObject.SetActive(false);
    }


    private void DeleteOldButtons()
    {
        foreach (Transform child in ResponseButtonContainer)
            Destroy(child.gameObject);
    }

    private string ParseText(string sentence)
    {
        bool hasPortraitPattern = Regex.IsMatch(sentence, @"\[p\d+\]");

        if (!hasPortraitPattern && npc != null)
            NPCPortrait.sprite = portraits[0];


        MatchCollection matchesWithNumber = Regex.Matches(sentence, patternWithNumber);
        MatchCollection matchesWithoutNumber = Regex.Matches(sentence, patternWithoutNumber);

        foreach (Match match in matchesWithNumber)
        {
            string type = match.Groups[1].Value;
            int number = Convert.ToInt16(match.Groups[2].Value);

            switch (type)
            {
                case "p":
                    sentence = sentence.Replace($"[p{number}]", "");
                    NPCPortrait.sprite = portraits[number];
                    break;
                case "i":
                    sentence = sentence.Replace($"[i{number}]", "");
                    FindObjectOfType<Inventory>().AddItem(Parameters.ItemsData[number], 1);
                    break;
            }
        }

        foreach (Match match in matchesWithoutNumber)
        {
            string type = match.Groups[1].Value;

            switch (type)
            {
                case "c":
                    sentence = sentence.Replace("[c]", Parameters.CatName);
                    break;
                case "nl":
                    sentence = sentence.Replace("[nl]", "");
                    Parameters.CanSleep = true;
                    break;
            }
        }

        return sentence;
    }

    private void EndDialogue()
    {
        isTalking = false;
        DialoguePanel.SetActive(false);
        player.CanMove = true;
        currentDialogue = null;
        currentDialogueData = null;

        foreach (var str in strings)
        {
            if(str.Length != 0)
                npc.Myselfdata.SavedKeys.Add(str);
        }

        strings.Clear();
        npc = null;
        currentTextIndex = 0;
    }
}
