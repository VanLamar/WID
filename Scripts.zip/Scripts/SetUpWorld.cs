﻿using UnityEngine;
using UnityEngine.UI;
using static HatCategory;

public class SetUpWorld : MonoBehaviour
{
    public static SetUpWorld Instance;
    public GameObject[] ImportantObjects;

    [HideInInspector] public WorldParameters Parameters;
    [SerializeField] private Slider MentalLive;

    private float gameHours = 12f;
    private float gameMinutes = 0f;
    private float gameSeconds = 0f;
    private float timeScale = 50f;
    private GameObject player;

    private void Start()
    {
        Instance = this;
        Parameters = WorldParameters.Instance;
        player = FindObjectOfType<PlayerController>().gameObject;
        Localization.LoadLocalizationFile(Parameters.LangKey);
        LoadHat(Parameters.DataPlayer.Hat);
        LoadHat(Parameters.DataPlayer.Accessory);
        player.GetComponent<Inventory>().LoadInventory();


        switch (Parameters.State)
        {
            case WorldParameters.TypeState.Day:
                Day();
                break;
            case WorldParameters.TypeState.Night:
                Night();
                break;
        }
    }

    private void Night() 
    {
        MentalLive.value = Parameters.DataPlayer.MentalHealth;
        MentalLive.gameObject.SetActive(true);
        player.transform.position = Parameters.DataPlayer.CurrentPossition;
    }
    private void Day() 
    {
        MentalLive.gameObject.SetActive(false);
    }

    private void Update()
    {
        gameSeconds += Time.deltaTime * timeScale;

        if (gameSeconds >= 60f)
        {
            gameMinutes++;
            gameSeconds -= 60f;
        }


        if (gameMinutes >= 60f)
        {
            gameHours++;
            gameMinutes -= 60f;
        }

        Parameters.Time = $"{gameHours.ToString("00")}:{gameMinutes.ToString("00")}";
    }

    private void LoadHat(HatCategory hat)
    {
        if (hat == null)
            return;

        GameObject outfit = null;
        switch (hat.outfitType)
        {
            case OutfitType.Hat:
                outfit = player.transform.Find("Hat")?.gameObject;
                break;
            case OutfitType.Accessory:
                outfit = player.transform.Find("Accessory")?.gameObject;
                break;
        }

        outfit.GetComponent<SpriteRenderer>().sprite = hat.Icon;
        outfit.transform.localPosition = hat.newPoss;
        outfit.transform.localScale = hat.newScale;
        outfit.GetComponent<Outfit>().hat = hat;
    }
}
