﻿using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "WorldParameters", menuName = "Custom/WorldParameters")]
public class WorldParameters : ScriptableObject
{
    public static WorldParameters Instance { get; private set; }
    public int Day = 0;
    public string LangKey = "en";
    public string Time = "";
    public string CatName = "";
    public bool CanSleep = false;
    public TypeState State;
    public enum TypeState { Day, Night }
    public List<Item> ItemsData = new List<Item>();
    public PlayerData DataPlayer;


    private void OnEnable()
    {
        Instance = this;
    }
}

[System.Serializable]
public class PlayerData 
{
    public int MentalHealth = 100;
    public string CurrentLocation;
    public string CurrentSubLocation;
    public Vector2 CurrentPossition;
    public Vector2 LastPossition;
    public bool Gossips;
    public HatCategory Hat;
    public HatCategory Accessory;
}
